from datasets.new_allweather import *

__all__ = ["NewAllWeather"]
